/* hello application */
#include "libhello.h"

int main (void)
{
	be_friendly();
	return 0;
}

