extern int be_friendly(void);
