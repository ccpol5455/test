/* hello world library */
#include <stdio.h>

int be_friendly(void)
{
	printf("Hello, World!\n");
	return 0;
}
